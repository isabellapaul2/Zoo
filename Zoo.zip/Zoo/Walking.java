
/**
 * Write a description of interface Walking here.
 *
 * @author (your name)
 * @version (a version number or a date)
 */
public interface Walking
{
    public String walk();
}
