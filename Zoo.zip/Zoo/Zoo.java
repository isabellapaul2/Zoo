import java.util.List;
import java.util.ArrayList;
import java.util.concurrent.TimeUnit;
import java.util.Random;
import java.util.Scanner;
/**
 * Write a description of class ZooTester here.
 *
 * @author (your name)
 * @version (a version number or a date)
 */
public class Zoo
{
    public static void main(String[] args) throws InterruptedException
    {

        List<Animal> animals = new ArrayList<>();

        System.out.println("Welcome to the Zoo!\n");
        System.out.print("Building the cages");
        delayDots(3);
        System.out.print("Populating the animals");
        populateAnimals(animals);
        delayDots(3);
        System.out.print("Hiring zookeepers");
        delayDots(3);

        Scanner in = new Scanner(System.in);
        System.out.println("\nYou are standing in a wondrous zoo. What would you like to do?");
        System.out.println("Type help to find out what you can do.\n");
        String text = in.nextLine();
        String msg ="";

        while(!text.equals("leave"))
        {
            switch(text)
            {
                default : msg = "You flail helplessly with indicision.";
                case"help":  
                msg = "Do you want to visitcages, lunchtime, listen to animals, look up, look around, look down, or become a zookeeper!? ";
                break;

                case"visitcages":
                msg = visitCages(animals);
                break;

                case"lunchtime":  
                msg = lunchtime(animals);
                break;

                case"listen to animals":  
                msg = listen(animals);
                break;

                case"look up":  
                msg = lookUp(animals);
                break;

                case"look around":  
                msg = lookAround(animals);
                break;

                case"look down":  
                msg = lookDown(animals);
                break;

                case"become a zookeeper":
                System.out.println(zooKeeper());
                text = in.nextLine();
                while (text != "I don't want to zooKeep")
                {
                    switch(text)
                    {
                        case"Velociraptor":
                        msg = Velociraptor();
                        break;
                        case"Trex":
                        msg = Trex();
                        break;
                        case"Vince":
                        msg = Vince();
                        break;
                        case"Lochnessmonster":
                        msg = Lochnessmonster();
                        break;
                        case"Bella":
                        msg = Bella();
                        break;
                        case"Bigfoot":
                        msg = Bigfoot();
                        break;
                        case"Abominablesnowman":
                        msg = Abominablesnowman();
                        break;
                        case"FleshMonster":
                        msg = FleshMonster();
                        break;
                        case"Anaconda":
                        msg = Anaconda();
                        break;
                        case"Droid":
                        msg = Droid();
                        break;
                        case"GoldFish":
                        msg = GoldFish();
                        break;
                        case"IronTarkus":
                        msg = IronTarkus();
                        break;
                        case"Thwomp":
                        msg = Thwomp();
                        break;
                        case"Megalodon":
                        msg = Megalodon();
                        break;
                        case"Goomba":
                        msg = Goomba();
                        break;
                        case"Bunny":
                        msg = Bunny();
                        break;
                        case"Shark":
                        msg = Shark();
                        break;
                        case"Phish":
                        msg = Phish();
                        break;
                        case"FruitBat":
                        msg = FruitBat();
                        break;
                        case"SunBear":
                        msg = SunBear();
                        break;
                        case"Llama":
                        msg = Llama();
                        break;
                        case"Walter":
                        msg = Walter();
                        break;
                        case"Platypus":
                        msg = Platypus();
                        break;
                        case"Rhino":
                        msg = Rhino();
                        break;
                        case"RedPanda":
                        msg = RedPanda();
                        break;
                        case"RedCrowCrane":
                        msg = RedCrowCrane();
                        break;
                        case"Moblin":
                        msg = Moblin();
                        break;
                        case"Lizalfo":
                        msg = Lizalfo();
                        break;
                        case"Bokoblin":
                        msg = Bokoblin();
                        break;
                        case"LR57CombatDroid":
                        msg = LR57CombatDroid();
                        break;
                        case"Duck":
                        msg = Duck();
                        break;
                        case"MourningDove":
                        msg = MourningDove();
                        break;
                        case"JapaneseMacaque":
                        msg = JapaneseMacaque();
                        break;
                        case"JapaneseGiantSalamander":
                        msg = JapaneseGiantSalamander();
                        break;
                        case"HomunculusFleshPuppet":
                        msg = HomunculusFleshPuppet();
                        break;
                    }
                 System.out.println(msg);
                msg = zooKeeper();
                System.out.println(msg);
                text = in.nextLine();
                break;
                }
            }
            System.out.println("\n" + msg);
            delayDots(3);
            System.out.println("What now? ");
            text = in.nextLine();
        }

        System.out.println("There were " + Animal.numAnimals + " animals created and added to the list.");
    }

    public static void delayDots(int dotAmount) throws InterruptedException
    {
        for(int i = 0; i<dotAmount; i++)
        {
            TimeUnit.SECONDS.sleep(1);
            System.out.print(".");
        }
        System.out.println();
    }

    public static void delayDots() throws InterruptedException
    {
        delayDots(0);   
    }

    public static void populateAnimals(List<Animal> animals)
    {
        Trex a1 = new Trex();
        Vince a2 = new Vince();
        Megalodon a3 = new Megalodon();
        Velociraptor a4 = new Velociraptor();
        Lochnessmonster a5 = new Lochnessmonster();
        Bella a6 = new Bella();
        Bigfoot a7 = new Bigfoot();
        Abominablesnowman a8 = new Abominablesnowman();
        FleshMonster a9 = new FleshMonster();
        Anaconda a10 = new Anaconda();
        Droid a11 = new Droid();
        GoldFish a12 = new GoldFish();
        IronTarkus a13 = new IronTarkus();
        Thwomp a14 = new Thwomp();
        Goomba a15 = new Goomba();
        Anaconda a16 = new Anaconda();
        Bunny a17 = new Bunny();
        Shark a18 = new Shark();
        Phish a19 = new Phish();
        FruitBat a20 = new FruitBat();
        SunBear a21 = new SunBear();
        Llama a22 = new Llama();
        Walter a23 = new Walter();
        Platypus a24 = new Platypus();
        Rhino a25 = new Rhino();
        RedPanda a26 = new RedPanda();
        RedCrowCrane a27 = new RedCrowCrane();
        Moblin a28 = new Moblin();
        Lizalfo a29 = new Lizalfo();
        Bokoblin a30 = new Bokoblin();
        LR57CombatDroid a31 = new LR57CombatDroid();
        Duck a32 = new Duck();
        MourningDove a33 = new MourningDove();
        JapaneseMacaque a34 = new JapaneseMacaque();
        JapaneseGiantSalamander a35 = new JapaneseGiantSalamander();
        HomunculusFleshPuppet a36 = new HomunculusFleshPuppet();

        animals.add(a1);
        animals.add(a2);
        animals.add(a3);
        animals.add(a4);
        animals.add(a5);
        animals.add(a6);
        animals.add(a7);
        animals.add(a8);
        animals.add(a9);
        animals.add(a10);
        animals.add(a11);
        animals.add(a12);
        animals.add(a13);
        animals.add(a14);
        animals.add(a15);
        animals.add(a16);
        animals.add(a17);
        animals.add(a18);
        animals.add(a19);
        animals.add(a20);
        animals.add(a21);
        animals.add(a22);
        animals.add(a23);
        animals.add(a24);
        animals.add(a25);
        animals.add(a26);
        animals.add(a27);
        animals.add(a28);
        animals.add(a29);
        animals.add(a30);
        animals.add(a31);
        animals.add(a32);
        animals.add(a33);
        animals.add(a34);
        animals.add(a35);
        animals.add(a36);
    }

    public static String visitCages(List<Animal>animals)
    {
        String msg = "";
        for(Animal a: animals)
        {
            msg += a.getName() + ": \n     " + a.getDiscription() + "\n"; 
        }
        return msg;
    }

    public static String lunchtime(List<Animal>animals)
    {
        String msg = "";
        for(Animal a: animals)
        {
            msg += a.getName() + ": \n     " + a.eat()+ "\n"; 
        }
        return msg;
    } 

    public static String listen(List<Animal>animals)
    {
        String msg = "";
        for(Animal a: animals)
        {
            msg += a.getName() + ": \n     " + a.makeNoise()+ "\n"; 
        }
        return msg;
    } 

    public static String lookUp(List<Animal>animals)
    {
        String msg = "";
        for(Animal a: animals)
        {
            if(a instanceof Flying)
            {
                Flying f = (Flying)a;
                msg += a.getName() + ": \n" + f.fly() + "\n";
            }
        }
        return msg;
    }

    public static String lookAround(List<Animal>animals)
    {
        String msg = "";
        for(Animal a: animals)
        {
            if(a instanceof Walking)
            {
                Walking w = (Walking)a;
                msg += a.getName() + ": \n" + w.walk() + "\n";
            }
        }
        return msg;
    }

    public static String lookDown(List<Animal>animals)
    {
        String msg = "";
        for(Animal a: animals)
        {
            if(a instanceof Swimming)
            {
                Swimming s = (Swimming)a;
                msg += a.getName() + ": \n" + s.swim() + "\n";
            }
        }
        return msg;
    }

    public static String zooKeeper()
    {
        return "What animal would you like to go check on?";   
    }

    public static String Trex()
    {
        return "stay against a wall he will never be able to grab you";   
    }

    public static String Vince()
    {
        return "Give him blue rubber ducks to eat";   
    }

    public static String Megalodon()
    {
        return "they swim fast so swim faster to not die";   
    }

    public static String Velociraptor()
    {
        return "Its always messy dont slip on its lasts feedings blood";   
    }

    public static String Lochnessmonster()
    {
        return "who knows if its really there or just a lot floating still give it food though.";   
    }

    public static String Bella()
    {
        return "yeet she may eat her face";   
    }

    public static String Bigfoot()
    {
        return "Its the guy who kinda looks like chubaca";   
    }

    public static String Abominablesnowman()
    {
        return "just give him a few snowballs to chew on";   
    }

    public static String FleshMonster()
    {
        return "this guy only eats flesh so be careful";   
    }

    public static String Anaconda()
    {
        return "give this guy a fat rat";   
    }

    public static String Droid()
    {
        return "watch your head it may land on ur head and suck up ur hair";   
    }

    public static String GoldFish()
    {
        return "just clean the bowl and give it some flakes";   
    }

    public static String IronTarkus()
    {
        return "what is this again?";   
    }

    public static String Thwomp()
    {
        return "if you go under him continue to run fast";   
    }

    public static String Goomba()
    {
        return "give this guy a smash on the head";   
    }

    public static String Bunny()
    {
        return "aw just give em a lil carrot";   
    }

    public static String Shark()
    {
        return "how lame just throw ur annoying neighbor in there";   
    }

    public static String Phish()
    {
        return "pheed the phish phood";   
    }

    public static String Rhino()
    {
        return "take a whole shovel to pick up its nasty pooooo";   
    }

    public static String RedPanda()
    {
        return "idk what this needs done but make it look like its fine";   
    }

    public static String RedCrowCrane()
    {
        return "give it one of the phish from the other exibit";   
    }

    public static String FruitBat()
    {
        return "fruit?";   
    }

    public static String SunBear()
    {
        return "soooo its a sun bear does it go though photosynthesis?";   
    }

    public static String Llama()
    {
        return "EAT your meatloaf mannnnn!";   
    }

    public static String Walter()
    {
        return "whats a walter?";   
    }

    public static String Platypus()
    {
        return "ferb said platypus nver eat";   
    }

    public static String Moblin()
    {
        return "moblin are mobile just tell it to feed itself";   
    }

    public static String Lizalfo()
    {
        return "i think its a lizzard give it a fly or something";   
    }

    public static String Bokoblin()
    {
        return "im imaginging some grimlin thing so give it water but not after midnight;)";   
    }

    public static String LR57CombatDroid()
    {
        return "does this even need taken care of?";   
    }

    public static String Duck()
    {
        return "throw a loaf of bread at it";   
    }

    public static String MourningDove()
    {
        return "just give it a hug its sad";   
    }

    public static String JapaneseMacaque()
    {
        return "fortune cookie";   
    }

    public static String JapaneseGiantSalamander()
    {
        return "fortune cookie";   
    }

    public static String HomunculusFleshPuppet()
    {
        return "i feeel like it eats flowers?";   
    }
}

