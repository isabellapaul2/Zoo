
/**
 * Write a description of interface Flying here.
 *
 * @author (your name)
 * @version (a version number or a date)
 */
public interface Flying
{
   public String fly();
}
