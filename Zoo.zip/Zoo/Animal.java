
/**
 * Abstract class Animal - write a description of the class here
 *
 * @author (your name here)
 * @version (version number or date here)
 */
public abstract class Animal
{
    protected String name;
    protected String description;
    
    public static int numAnimals = 0;
    
    
    public Animal()
    {
        //takes one parameter string
        //passingin none for the name
        //this is called constructor chaining when one sonstuctor
        this ("none");
    }
    
    public Animal(String name)
    {
        //call the other constructor that takes two string parameter
        //passsing in the value referenced by the name and variabel 
        //none for the description
        this (name, "name");
    }
    
    public Animal(String name, String description)
    {
        this.name = name;
        this.description = description;
        //means another animal is created
        numAnimals++;
    }
    
    
    
    
    
    
    
    public void setName(String name)
    {
       this.name = name;
    }
    public String getName()
    {
        return this.name;
    }
    
    public void setDescription(String description)
    {
       this.description = description;
    }
    public String getDiscription()
    {
        return this.description;
    }
    
    
    
    
    @Override
    
    public String toString()
    {
        return this.name + ": " + this.description;
    }
    
    
    
    public abstract String eat();
    
    public abstract String makeNoise();
}
