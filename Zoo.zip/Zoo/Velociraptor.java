
/**
 * Write a description of class Frog here.
 *
 * @author (your name)
 * @version (a version number or a date)
 */
public class Velociraptor extends Animal
    implements Walking, Swimming
{
    public Velociraptor()
    {
     this("Vinny", "My big toe never touches the ground");   
    }
    
    public Velociraptor(String name, String description)
    {
     super(name, description);   
    }
    
    @Override
    
    public String eat()
    {
        return "I eat baby cats";
    }
    
    @Override
    
    public String makeNoise()
    {
      return "*EKKKKKKKK*";
    }
    
    @Override
    
    public String walk()
    {
        return "THWAP THWAP";
    }
    
    @Override
    
    public String swim()
    {
        return "SPLEEP SPLOT";
    }
}
