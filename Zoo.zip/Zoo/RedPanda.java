
/**
 * Write a description of class RedPanda here.
 *
 * @author (your name)
 * @version (a version number or a date)
 */
public class RedPanda extends Animal
{
    public RedPanda()
    {
        this("Akio", "Loving the Weather");
    }
    
    public RedPanda(String name, String Decription)
    {
        super(name, Decription);
    }
    
    @Override
    
    public String makeNoise()
    {
       return "Squeek";
    }
    
    @Override
    
    public String eat()
    {
       return "Crunch";
    }
}
